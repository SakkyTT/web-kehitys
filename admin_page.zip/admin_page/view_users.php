<?php

// Tässä tiedostossa listataan kaikki käyttäjät taulukossa
// Taulukossa on napit, joilla käyttäjä voidaan poistaa tai muokata

// 1. Haetaan käyttäjien tiedot
//     a. Tietokanta yhteys (erillinen tiedosto)
//     b. SQL lause ja sen suoritus ja siitä datan haku
//
// 2. Generoidaan käyttöliittymä haetun datan perusteella


// Tietokanta yhteyden koodit löytyy tästä tiedostosta
require_once 'db_connection.inc.php';

// $queryString = "SELECT * FROM users" // Voi olla myös erillinen muuttuja SQL lauseelle
$stmt = $pdo_conn->prepare("SELECT UserID, Username, email FROM users");

$stmt->execute(); // Suoritetaan SQL lause
$users = $stmt->fetchAll(PDO::FETCH_ASSOC); // Tallennetaan data muuttujaan

?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Users</title>
</head>
<body>
    <!-- Tähän taulukkoon generoidaan rivejä $users muuttujan datan perusteella -->
    <table>
        <!-- Otsikko rivi -->
        <tr>
            <th>ID</th>
            <th>Username</th>
            <th>Email</th>
            <th>Actions</th>
        </tr>
        <!-- Loopataan läpi $users array ja generoidaan rivejä taulukkoon -->
        <?php foreach($users as $user): ?>    

            <tr> <!-- Uusi user rivi alkaa -->

                <!-- <td><?php// echo $user["UserID"]; ?></td>  -->
                <td><?= $user["UserID"] ?></td><!-- td on rivin sarakkeita -->
                <td><?= htmlspecialchars($user["Username"]) ?></td>
                <td><?= htmlspecialchars($user["email"]) ?></td>
                <td> <!-- Actions sarake -->

                    <!-- Poistetaan käyttäjä tällä sivulla -->
                    <form action="view_users.php" method="post">
                        <input type="hidden" name="user_id" value="<?= $user["UserID"] ?>">
                        <button name="delete" type="submit">Delete</button>
                        <!-- isset($_POST["delete"]) -->
                    </form>

                    <!-- $_GET["userId"] -->
                    <a href="edit_user.php?userId=<?= $user["UserID"] ?>">Edit</a>

                </td><!-- Actions sarake päättyy -->

            </tr> <!-- User rivi päättyy -->

        <?php endforeach; ?>
    </table>
</body>
</html>
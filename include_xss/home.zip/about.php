
<?php
    include 'partials/header.php';
    ?>
    <main>
        <h1>About</h1>
        <p>Content for about</p>
    </main>
    <?php
    include 'partials/footer.php';
    ?>
</body>
</html>
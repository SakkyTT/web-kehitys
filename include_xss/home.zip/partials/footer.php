<footer>
        <h2>Footer content here</h2>
    </footer>
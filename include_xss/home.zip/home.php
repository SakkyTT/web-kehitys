
<?php
    include 'partials/header.php';
    ?>
    <main>
        <h1>Home</h1>
        <p>Content for home</p>
    </main>
    <?php
    include 'partials/footer.php';
    ?>
</body>
</html>
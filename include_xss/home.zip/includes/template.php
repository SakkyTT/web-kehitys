<?php
    echo '<div>
    <img style="width: 100px" src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/75/Granodiorite_of_the_Fennoscandian_Shield.jpg/1199px-Granodiorite_of_the_Fennoscandian_Shield.jpg?20150331203241" alt="">
    <p>Name</p>
    </br>
    </div>';
?>
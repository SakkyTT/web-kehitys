
    <?php
    include 'partials/header.php';
    ?>
    <main>
        <h1>Contact</h1>
        <p>Content for contact</p>
    </main>
    <?php
    include 'partials/footer.php';
    ?>
</body>
</html>
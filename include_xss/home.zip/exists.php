<?php 
    echo 'Hello from another file!';
?>